# Foundry VTT 5th Edition

An implementation of the Dungeons & Dragons 5th Edition game system for Foundry Virtual Tabletop (http://foundryvtt.com).

The software component of this system is distributed under the GNUv3 license while the game content is distributed
under the Open Gaming License v1.0a.

The systems reference document (SRD) for included content is available in full from Wizards of the Coast:
http://media.wizards.com/2016/downloads/DND/SRD-OGL_V5.1.pdf